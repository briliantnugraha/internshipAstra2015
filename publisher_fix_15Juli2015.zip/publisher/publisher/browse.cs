﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace publisher
{
    class browse
    {
        private FolderBrowserDialog fbd;
        private SaveFileDialog sfd;
        private OpenFileDialog ofd;

        public browse()
        {
            fbd = new FolderBrowserDialog();
            sfd = new SaveFileDialog();
            ofd = new OpenFileDialog();
        }

        public String browseFolder()
        {
            if (fbd.ShowDialog() == DialogResult.OK) return fbd.SelectedPath;
            else return null;
        }
        public String browseFile()
        {
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                return ofd.FileName;
            }
            else return null;
        }

        public String saveFile()
        {
            sfd.FileName = "publish" + DateTime.Now.ToString("-yyyy-MM-dd");
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                System.IO.Path.GetDirectoryName(sfd.FileName); // memasukkan path ke sfd.filename
                return sfd.FileName;
            }
            else return null;
        }
    }
}
