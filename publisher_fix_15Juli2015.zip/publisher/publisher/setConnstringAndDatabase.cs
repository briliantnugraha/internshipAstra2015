﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace publisher
{
    public partial class setConnstringAndDatabase : Form
    {
        private String directoryJob, listOfJob, pathConnString, directoryConfigServerAndDB, databaseNew, listDatabase;
        private PathForm pathForm;
        private browse Browse;
        private ConnStringAndDatabase connstringAndDatabase;
        private int iter;

        public setConnstringAndDatabase(String dirJob, String listJob)
        {
            InitializeComponent();
            pathForm = new PathForm();
            Browse = new browse();
            connstringAndDatabase = new ConnStringAndDatabase();

            directoryConfigServerAndDB = AppDomain.CurrentDomain.BaseDirectory;
            this.directoryJob = dirJob;
            this.listOfJob = listJob;
            pathConnString = String.Empty;
            databaseNew = String.Empty;
            loadListDB();
            //MessageBox.Show(this.directoryJob + "\n" + this.listOfJob);
        }

        //ini untuk meload semua list database yang telah dimasukkan sebelumnya
        private void loadListDB()
        {
            listDatabase = null;
            listDatabase = connstringAndDatabase.loadListDB(directoryConfigServerAndDB);
            //MessageBox.Show(listDatabase);
            if(listDatabase!=null)
            {
                String[] listDatabaseInStringArray = listDatabase.Split('\n');
                listDB.Items.Clear();
                listDB.Text = listDatabaseInStringArray[0];
                for (iter = 1; iter < listDatabaseInStringArray.Length - 1; iter++) listDB.Items.Add(listDatabaseInStringArray[iter]);
            }            
        }

        //ini untuk mencari file dan path connstring
        private void browseConnstring_Click(object sender, EventArgs e)
        {
            pathConnString = Browse.browseFile();
            Connstring.Text = pathConnString;
            connstringAndDatabase.checkServer(directoryConfigServerAndDB, pathConnString);
            MessageBox.Show("Server berhasil di set ke " + pathConnString);
        }

        //ini untuk menambah database baru ke dalam config, lalu akan diload kembali list database nya
        private void addDatabase_Click(object sender, EventArgs e)
        {
            databaseNew = dbName.Text;
            connstringAndDatabase.checkDB(directoryConfigServerAndDB, databaseNew);
            loadListDB();
        }

        //ini untuk meng set semua file yang dipilih sesuai dgn connstring dan database yang telah diubah
        private void setConnstrAndDB_Click(object sender, EventArgs e)
        {
            if(String.IsNullOrEmpty(Connstring.Text) || String.IsNullOrWhiteSpace(Connstring.Text))
            {
                Connstring.Text = connstringAndDatabase.getConnString(directoryConfigServerAndDB);
            }
            //MessageBox.Show(Connstring.Text);
            connstringAndDatabase.setConnstrAndDB(directoryConfigServerAndDB, Connstring.Text, listDB.Text, this.directoryJob, this.listOfJob);
        }

        private void Default_Click(object sender, EventArgs e)
        {
            Connstring.Text = connstringAndDatabase.getConnString(directoryConfigServerAndDB);
            listDB.Text = connstringAndDatabase.getSelectedDB(directoryConfigServerAndDB);
        }

    }
}
