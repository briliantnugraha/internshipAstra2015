﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 * Developed by : Brilian T. Nugraha and Muhammad Farid Wajdi
 * College student of Sepuluh Nopember Institute of Technology, 2012 generation
 * 
 * keterangan :
     * folderTemplate, index ke - :
     * 0.   1.script_pre
     * 1.   2.execETL
     * 2.   3.jobs
     * 3.   4.sp
     * 4.   5.script_post
     * 5.   6.config
     * 6.   7.listExecuteETL
 * 
     * folderPublisher, index ke - :
     * 0.   1.script_pre
     * 1.   2.execETL
     * 2.   3.jobs
     * 3.   4.sp
     * 4.   5.script_post
     * 5.   6.config
 */


namespace publisher
{
    public partial class Form1 : Form
    {
        private int iter;
        private Form form;
        private ButtonForm button;
        private PathForm pathForm;
        private ConnStringAndDatabase connstringAndDatabase;
        private generate Generate;
        private load loadScript;

        private String Messenger, directoryConfig, connStrFilePath, selectedDB, directoryConfigServerAndDB; //berfungsi sebagai pembawa String ke form/fungsi lain
        private String[] getPublishFolderPath, folderPublisher, folderTemplate;
        private DataGridViewButtonColumn dgvButtonColumn;
        private DataGridViewTextBoxColumn dgvTextBoxColumn;
        private DataGridViewCheckBoxColumn dgvCheckBoxColumn;


        public Form1()
        {
            InitializeComponent();
            setVariable();
            initializeGrid();
        }

        private void setVariable()
        {
            this.Text = "Publisher";

            pathForm = new PathForm();
            button = new ButtonForm();
            connstringAndDatabase = new ConnStringAndDatabase();
            Messenger = String.Empty;
            directoryConfig = AppDomain.CurrentDomain.BaseDirectory;
            connStrFilePath = null;
            selectedDB = null;
            getPublishFolderPath = new String[2];
            folderPublisher = new String[7];
            folderTemplate = new String[7];
            Generate = new generate();
            textBox1.Text = null;
            loadScript = new load();
            // mengatur button agar tidak dapat di klik
            for (iter = 0; iter < this.Controls.Count; iter++ )
            {
                if (button.enableOrDisable(this.Controls[iter].Name, "button", 6) == 0)
                    this.Controls[iter].Enabled = false;
            }
        }

        private void initializeGrid()
        {
            dgvButtonColumn = new DataGridViewButtonColumn();
            dgvCheckBoxColumn = new DataGridViewCheckBoxColumn();
            dgvTextBoxColumn = new DataGridViewTextBoxColumn();

            //membuat kolom status
            dgvTextBoxColumn.HeaderText = "Status";
            dgvTextBoxColumn.Name = "Status";
            dgvTextBoxColumn.Width = 70;
            dgvTextBoxColumn.ReadOnly = true;
            dataGridView1.Columns.Add(dgvTextBoxColumn);

            //membuat kolom generate
            dgvCheckBoxColumn.HeaderText = "Generate";
            dgvCheckBoxColumn.Name = "Generate";
            dgvCheckBoxColumn.Width = 50;
            dataGridView1.Columns.Add(dgvCheckBoxColumn);

            //membuat kolom ETLProcessName
            dgvTextBoxColumn = new DataGridViewTextBoxColumn();
            dgvTextBoxColumn.HeaderText = "ETLProcessName";
            dgvTextBoxColumn.Name = "ETLProcessName";
            dgvTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns.Add(dgvTextBoxColumn);

            //membuat kolom SP
            dgvCheckBoxColumn = new DataGridViewCheckBoxColumn();
            dgvCheckBoxColumn.HeaderText = "SP";
            dgvCheckBoxColumn.Name = "SP";
            dgvCheckBoxColumn.Width = 50;
            dataGridView1.Columns.Add(dgvCheckBoxColumn);

            //membuat kolom Jobs
            dgvCheckBoxColumn = new DataGridViewCheckBoxColumn();
            dgvCheckBoxColumn.HeaderText = "Jobs";
            dgvCheckBoxColumn.Name = "Jobs";
            dgvCheckBoxColumn.Width = 50;
            dataGridView1.Columns.Add(dgvCheckBoxColumn);

            //membuat kolom Edit
            dgvButtonColumn.HeaderText = "Edit";
            dgvButtonColumn.Name = "Edit";
            dgvButtonColumn.Width = 50;
            dgvButtonColumn.Text = "Edit";
            dataGridView1.Columns.Add(dgvButtonColumn);

            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToOrderColumns = true;
        }

        private void getFolder()
        {
            //getPublishFolderPath[0 -> path folder template, 1 -> path folder publish]
            folderPublisher = pathForm.checkOrMakeFolder(getPublishFolderPath[1]);
            //MessageBox.Show(getPublishFolderPath[0]);
            folderTemplate = pathForm.checkOrMakeFolder(getPublishFolderPath[0]);
            
            try
            {
                String[] listFileFromFolderExecuteETL = pathForm.listFile(folderTemplate[6]);
                // menampilkan list ETL dari folder template dengan referensi dari folder listExecuteETL
                // splitListFileFromFolderExecuteETL akan mendapatkan nama folder yang telah displit berdasarkan slash atau '/'
                // lalu yang akan dimasukkan adalah nilai splitListFileFromFolderExecuteETL yaitu nama file nya, di codemenggunakan [string.length - 1]
                // lalu karena file nya memiliki ekstensi, maka ekstensi nya dihilangkan, di code menggunakan remove(string.length - 4)
                for (iter = 0; iter < listFileFromFolderExecuteETL.Length; iter++)
                {
                    String[] splitListFileFromFolderExecuteETL = listFileFromFolderExecuteETL[iter].Split('/');
                    this.dataGridView1.Rows.Add("Belum edit", "True",
                        splitListFileFromFolderExecuteETL[splitListFileFromFolderExecuteETL.Length - 1].
                        Remove(splitListFileFromFolderExecuteETL[splitListFileFromFolderExecuteETL.Length - 1].Length - 4),
                        "True", "True", "Edit");
                }
            }

            catch (Exception except)
            {
                MessageBox.Show("Maaf, folder yang anda tuju tidak ada!\n Error : " + except.ToString());
            }
        }

        //ini button browse
        private void button1_Click(object sender, EventArgs e)
        {
            //mendapat path folder template dan membuat folder publish
            getPublishFolderPath = pathForm.getFolderPath(textBox1.Text);

            if (getPublishFolderPath[0] != null && getPublishFolderPath[1] != null)
            {
                // setelah folder dibrowse, baru di enable button clear table dan button set connstring an database
                for (iter = 0; iter < this.Controls.Count; iter++)
                {
                    if (button.enableOrDisable(this.Controls[iter].Name, "button", 4) == 0)
                        this.Controls[iter].Enabled = true;
                }

                getFolder();
            }
            else MessageBox.Show("Maaf, folder template tidak ada, sehingga publish tidak dapat dilakukan");            
        }

        private void getListETLProcessName()
        {
            Messenger = null;
            for (iter = 0; iter < dataGridView1.Rows.Count; iter++)
            {
                if (dataGridView1.Rows[iter].Cells[1].Value.ToString() == "True")
                    Messenger += dataGridView1.Rows[iter].Cells[2].Value.ToString() + "\r\n";
            }
        }

        //ini button set connstring and database
        private void button2_Click(object sender, EventArgs e)
        {
            getListETLProcessName();
                //menampilkan form set connstring and database
            form = new setConnstringAndDatabase(folderTemplate[2], Messenger);
            form.Show();
        }

        //ini button untuk meng clear grid list file yang akan di generate di form
        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }

        //ini button untuk menggenerate file
        private void button4_Click(object sender, EventArgs e)
        {
            directoryConfigServerAndDB = AppDomain.CurrentDomain.BaseDirectory;
            connStrFilePath = connstringAndDatabase.getConnString(directoryConfigServerAndDB);
            selectedDB = connstringAndDatabase.getSelectedDB(directoryConfigServerAndDB);
            getListETLProcessName();

            MessageBox.Show(connStrFilePath + "\n" + selectedDB);

            if (!String.IsNullOrEmpty(connStrFilePath) && !String.IsNullOrWhiteSpace(connStrFilePath)
                && !String.IsNullOrEmpty(selectedDB) && !String.IsNullOrWhiteSpace(selectedDB))
            {
                connstringAndDatabase.setConnstrAndDB(directoryConfig, connStrFilePath, selectedDB, folderTemplate[2], Messenger);

                String[] MessengerSplit = Messenger.Split('\n');
                Generate.copySP(folderTemplate[3], folderPublisher[3], MessengerSplit);
                Generate.generateConfig(folderTemplate[6], folderTemplate[5], folderPublisher[5], MessengerSplit);
                Generate.generateInsertExecuteETL(folderTemplate[6], folderTemplate[1], folderPublisher[1], MessengerSplit);
                Generate.generateJob(folderPublisher[5], folderTemplate[6], folderTemplate[2], folderPublisher[2], MessengerSplit);

                for (iter = 0; iter < this.Controls.Count; iter++)
                {
                    if (button.enableOrDisable(this.Controls[iter].Name, "button", 5) == 0)
                        this.Controls[iter].Enabled = true;
                }

            }
            else MessageBox.Show("Connstring dan database belum di set");
        }

        //ini button untuk load file
        private void button5_Click(object sender, EventArgs e)
        {
            //akan meload script dari folder publisher di sub dir jobs dan execETL
            loadScript.LoadAll(folderPublisher[2],folderPublisher[1], folderPublisher[3]);
        }
    }
}
