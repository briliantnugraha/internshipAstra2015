﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace publisher
{
    class generate
    {
        private String[] getListSP, getListJob, getListInsertExecETL, getListConfig;
        private String getSO;
        private int iter, iter2, iter3;
        private TextWriter writer;
        private XmlDocument xdoc;
        private XmlNode node;
        private XmlNodeList listNode;
        private XmlElement element;

        public void copySP(String folderSPTemplate, String folderSPPublisher, String[] fileSPToCopy)
        {
            getListSP = Directory.GetFiles(folderSPTemplate);
            
            for(iter2 = 0; iter2 < fileSPToCopy.Length - 1; iter2++)
                fileSPToCopy[iter2] = fileSPToCopy[iter2].Remove(fileSPToCopy[iter2].Length - 1);

            for (iter = 0; iter < getListSP.Length; iter++)
            {
                String[] list2 = getListSP[iter].Split('/');
                list2[list2.Length - 1] = list2[list2.Length - 1].Remove(list2[list2.Length - 1].Length - 4);
                for(iter2 = 0; iter2 < fileSPToCopy.Length - 1; iter2++)
                {
                    if (list2[list2.Length - 1] == fileSPToCopy[iter2])
                    {
                        if (!File.Exists(folderSPPublisher + list2[list2.Length - 1] + ".txt")) 
                            File.Copy(getListSP[iter], folderSPPublisher + list2[list2.Length - 1] + ".txt");
                        break;
                    }
                }
            }
        }

        private void getListToGenerateJob(String dirConfig, String SOTransDB, String jobDirTemplate, String jobDirPublisher,String jobName, String master = null)
        {
            if (master == "master")
            {
                generateListJob(dirConfig, jobDirTemplate, jobDirPublisher, jobName, master);
            }

            else
            {
                generateListJob(dirConfig, jobDirTemplate, jobDirPublisher, jobName, SOTransDB);
            }
            
        }

        private void generateListJob(String dirConfig, String jobDirTemplate, String jobDirPublisher, String jobName, String SOTransDB)
        {
            if (SOTransDB == null) SOTransDB = "master";
            if (!File.Exists(jobDirPublisher + jobName + "_" + SOTransDB + ".xml"))
            {
                File.Copy(jobDirTemplate + jobName + ".xml", jobDirPublisher + jobName + "_" + SOTransDB + ".xml");
            }

            else
            {
                File.Delete(jobDirPublisher + jobName + "_" + SOTransDB + ".xml");
                File.Copy(jobDirTemplate + jobName + ".xml", jobDirPublisher + jobName + "_" + SOTransDB + ".xml");
            }

            xdoc = new XmlDocument();
            xdoc.Load(jobDirPublisher + jobName + "_" + SOTransDB + ".xml");

            if (jobName.Split('_')[0] == "PSS")
            {
                node = null;
                node = xdoc.SelectSingleNode("jobs/path3");
                node.InnerText = " /CONFIGFILE " + dirConfig;

                node = null;
                node = xdoc.SelectSingleNode("jobs/config");
                node.InnerText = jobName + "_" + SOTransDB + ".dtsConfig" + " /CONFIGFILE   /CHECKPOINTING OFF /REPORTING E";
            }
            else if(jobName.Split('_')[0] == "DW")
            {
                node = null;
                //System.Windows.Forms.MessageBox.Show(SOTransDB);
                node = xdoc.SelectSingleNode("jobs/path3");
                node.InnerText += ",''" + SOTransDB + "''";
            }
            xdoc.Save(jobDirPublisher + jobName + "_" + SOTransDB + ".xml");
        }

        public void generateJob(String dirConfig, String listExecuteETLTemplate, String dirTemplateJob, String dirPublisherJob, String[] listOfGenerateFile)
        {
            getListJob = System.IO.Directory.GetFiles(dirTemplateJob);
            for (iter = 0; iter < getListJob.Length; iter++)
            {
                String[] list2 = getListJob[iter].Split('/');
                list2[list2.Length - 1] = list2[list2.Length - 1].Remove(list2[list2.Length - 1].Length - 4);
                for (iter2 = 0; iter2 < listOfGenerateFile.Length - 1; iter2++)
                {
                    //System.Windows.Forms.MessageBox.Show(list2[list2.Length - 1] + "\n\n" + listOfGenerateFile[iter2]);
                    if (list2[list2.Length - 1] == listOfGenerateFile[iter2])
                    {
                        //System.Windows.Forms.MessageBox.Show(listExecuteETLTemplate + listOfGenerateFile[iter2] + ".xml");
                        if (File.Exists(listExecuteETLTemplate + listOfGenerateFile[iter2] + ".xml"))
                        {
                            //System.Windows.Forms.MessageBox.Show(listExecuteETLTemplate + listOfGenerateFile[iter2] + ".xml");
                            xdoc = new XmlDocument();
                            xdoc.Load(listExecuteETLTemplate + listOfGenerateFile[iter2] + ".xml");
                            element = xdoc.DocumentElement;
                            listNode = element.ChildNodes;

                            if (listNode.Count > 0) //getListToGenerateJob(dirConfig, listNode, dirTemplateJob, dirPublisherJob, listOfGenerateFile[iter2]);
                            {
                                for(iter3=0; iter3 < listNode.Count; iter3++)
                                {
                                    //System.Windows.Forms.MessageBox.Show(listExecuteETLTemplate + listOfGenerateFile[iter2] + "_" + listNode[iter3].InnerText + ".xml");
                                    getListToGenerateJob(dirConfig, listNode[iter3].InnerText  , dirTemplateJob, dirPublisherJob, listOfGenerateFile[iter2]);
                                }
                            }

                            else
                            {
                                //System.Windows.Forms.MessageBox.Show(listOfGenerateFile[iter2] + " adalah master");
                                getListToGenerateJob(dirConfig, null, dirTemplateJob, dirPublisherJob, listOfGenerateFile[iter2], "master");
                            }
                        }
                        break;
                    }
                }
            }
        }

        public void generateInsertExecuteETL(String listExecuteETLTemplate, String dirTemplateInsertExecETL, String dirPublisherInsertExecETL, String[] listOfGenerateFile)
        {
            getListInsertExecETL = System.IO.Directory.GetFiles(dirTemplateInsertExecETL);

            for (iter = 0; iter < getListInsertExecETL.Length; iter++)
            {
                String[] list2 = getListInsertExecETL[iter].Split('/');
                list2[list2.Length - 1] = list2[list2.Length - 1].Remove(list2[list2.Length - 1].Length - 4);
                for (iter2 = 0; iter2 < listOfGenerateFile.Length - 1; iter2++)
                {
                    if (list2[list2.Length - 1] == listOfGenerateFile[iter2])
                    {
                        //System.Windows.Forms.MessageBox.Show(listExecuteETLTemplate + listOfGenerateFile[iter2] + ".xml");
                        if (File.Exists(listExecuteETLTemplate + listOfGenerateFile[iter2] + ".xml"))
                        {
                            //System.Windows.Forms.MessageBox.Show(listExecuteETLTemplate + listOfGenerateFile[iter2] + ".xml");
                            xdoc = new XmlDocument();
                            xdoc.Load(listExecuteETLTemplate + listOfGenerateFile[iter2] + ".xml");
                            element = xdoc.DocumentElement;
                            listNode = element.ChildNodes;

                            if (listNode.Count > 0)
                            {
                                for (iter3 = 0; iter3 < listNode.Count; iter3++)
                                {
                                    if (!File.Exists(dirPublisherInsertExecETL + listOfGenerateFile[iter2] + "_" + listNode[iter3].InnerText + ".xml"))
                                        File.Copy(dirTemplateInsertExecETL + listOfGenerateFile[iter2] + ".xml", dirPublisherInsertExecETL + listOfGenerateFile[iter2] + "_" + listNode[iter3].InnerText + ".xml");

                                    xdoc = new XmlDocument();
                                    getSO = null;
                                    xdoc.Load(dirPublisherInsertExecETL + listOfGenerateFile[iter2] + "_" + listNode[iter3].InnerText + ".xml");
                                    node = xdoc.SelectSingleNode("executeETL/SOTransDB");
                                    getSO = listNode[iter3].InnerText;
                                    node.InnerText = getSO;
                                    xdoc.Save(dirPublisherInsertExecETL + listOfGenerateFile[iter2] + "_" + listNode[iter3].InnerText + ".xml");
                                }
                            }

                            else
                            {
                                if (!File.Exists(dirPublisherInsertExecETL + listOfGenerateFile[iter2] + "_master.xml"))
                                    File.Copy(dirTemplateInsertExecETL + listOfGenerateFile[iter2] + ".xml", dirPublisherInsertExecETL + listOfGenerateFile[iter2] + "_master.xml");

                                xdoc.Load(dirPublisherInsertExecETL + listOfGenerateFile[iter2] + "_master.xml");
                                node = xdoc.SelectSingleNode("executeETL/SOTransDB");
                                getSO = null;
                                node.InnerText = getSO;
                                xdoc.Save(dirPublisherInsertExecETL + listOfGenerateFile[iter2] + "_master.xml");
                            }
                            break;
                        }
                    }


                }
            }
        }

        public void generateConfig(String listExecuteETLTemplate, String dirTemplateConfig, String dirPublisherConfig, String[] listOfGenerateFile)
        {
            getListConfig = Directory.GetFiles(dirTemplateConfig);
            for (iter2 = 0; iter2 < listOfGenerateFile.Length - 1; iter2++)
            {
                //System.Windows.Forms.MessageBox.Show(listExecuteETLTemplate + listOfGenerateFile[iter2] + ".xml");
                if (File.Exists(listExecuteETLTemplate + listOfGenerateFile[iter2] + ".xml"))
                {
                    xdoc = new XmlDocument();
                    xdoc.Load(listExecuteETLTemplate + listOfGenerateFile[iter2] + ".xml");
                    element = xdoc.DocumentElement;
                    listNode = element.ChildNodes;

                    if (listNode.Count > 0)
                    {
                        for (iter = 0; iter < listNode.Count; iter++)
                        {
                            String[] line = File.ReadAllLines(dirTemplateConfig + "transact.dtsConfig");
                            writer = new StreamWriter(dirPublisherConfig + listOfGenerateFile[iter2] + "_" + listNode[iter].InnerText + ".dtsConfig");

                            foreach (String t in line)
                            {
                                getSO = null;
                                if (t.Contains("[this object is going to be filled]")) getSO = t.Replace("[this object is going to be filled]", listOfGenerateFile[iter2]);
                                else if (t.Contains("[this trans is going to be filled]")) getSO = t.Replace("[this trans is going to be filled]", listNode[iter].InnerText);
                                else getSO = t;
                                writer.WriteLine(getSO);
                            }
                            writer.Close();
                        }
                    }

                    else
                    {
                        String[] line = File.ReadAllLines(dirTemplateConfig + "master.dtsConfig");
                        writer = new StreamWriter(dirPublisherConfig + listOfGenerateFile[iter2] + "_master.dtsConfig");
                        foreach (String t in line)
                        {
                            getSO = null;
                            if (t.Contains("[this object is going to be filled]")) getSO = t.Replace("[this object is going to be filled]", listOfGenerateFile[iter2]);
                            else getSO = t;
                            writer.WriteLine(getSO);
                        }
                        writer.Close();
                    }
                }
            }
        }
    }
}
