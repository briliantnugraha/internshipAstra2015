﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace publisher
{
    class PathForm
    {
        private String directoryPathPublisher, getDirectoryPathPublisher, pathFolderTemplate, pathFolderPublisher, signPath;
        private String[] folderTemplateAndPublish;
        private int iter;
        private TextWriter writerPathPublisher;
        private browse Browse;

        public PathForm()
        {
            Browse = new browse();
            directoryPathPublisher = AppDomain.CurrentDomain.BaseDirectory;
            pathFolderPublisher = String.Empty;
            pathFolderTemplate = String.Empty;
            signPath = String.Empty;
            folderTemplateAndPublish = new String[2];
        }

        private String checkPath(String path)
        {
            if (Directory.Exists(path))
            {
                if (Directory.Exists(path + "/1.script_pre/") &&
                    Directory.Exists(path + "/2.execETL/") &&
                    Directory.Exists(path + "/3.jobs/") &&
                    Directory.Exists(path + "/4.sp/") &&
                    Directory.Exists(path + "/5.script_post/") &&
                    Directory.Exists(path + "/6.config/") &&
                    Directory.Exists(path + "/7.listExecuteETL/"))
                {
                    return "exist";
                }
                else return "not exist";
            }
            
            else return "not exist";
        }

        public String[] getFolderPath(String folderPath)
        {
            //cek folder template ada atau tidak
            signPath = null;
            signPath = this.checkPath(folderPath);
            //MessageBox.Show(signPath );
            if (signPath == "not exist" )
            {
                if (String.IsNullOrEmpty(folderPath) || String.IsNullOrWhiteSpace(folderPath))
                    MessageBox.Show("Maaf, input yang anda masukkan kosong!");
                else
                    MessageBox.Show("Maaf, folder template yang anda masukkan tidak valid");
                pathFolderTemplate = String.Empty;
                pathFolderTemplate = Browse.browseFolder();
            }
            else if (signPath == "exist")
            {
                pathFolderTemplate = folderPath;
                MessageBox.Show("Template " + pathFolderTemplate + " berhasil diload!");
            }

            pathFolderPublisher = Browse.saveFile();
            if(pathFolderPublisher != null)
            {
                if (pathFolderTemplate != null) 
                    MessageBox.Show("Template " + pathFolderTemplate + " berhasil di load!, publisher " + pathFolderPublisher + " berhasil dibuat");
                Directory.CreateDirectory(pathFolderPublisher); // membuat directory save untuk publish
                writerPathPublisher = new StreamWriter(directoryPathPublisher + "pathPublisher.txt");
                writerPathPublisher.WriteLine(pathFolderPublisher);
                writerPathPublisher.Close();
            }
                
            else
            {
                try
                {
                    getDirectoryPathPublisher = File.ReadAllText(directoryPathPublisher + "pathPublisher.txt");
                    pathFolderPublisher = getDirectoryPathPublisher;
                }
                catch (Exception e)
                {
                    MessageBox.Show("Publisher folder tidak ada, Error : " + e.ToString());
                    return new String[2] { null, null };
                }
            }

            folderTemplateAndPublish = new String[2]{ pathFolderTemplate, pathFolderPublisher };
            return folderTemplateAndPublish;
        }

        public String[] checkOrMakeFolder(String folderPath)
        {
            String[] listFolder = { "/1.script_pre/", "/2.execETL/", "/3.jobs/", 
                                      "/4.sp/", "/5.script_post/", "/6.config/", 
                                      "/7.listExecuteETL/"};
            try
            {
                if (folderPath.Contains("\r\n")) folderPath = folderPath.Remove(folderPath.Length - 2);
                if (!Directory.Exists(folderPath)) Directory.CreateDirectory(folderPath);
                
                for (iter = 0; iter < listFolder.Length; iter++)listFolder[iter] = folderPath + listFolder[iter];
                
                String[] cekFolder = Directory.GetDirectories(folderPath);
                if (cekFolder.Length < 6)
                {
                    for (iter = 0; iter < (listFolder.Length - 1); iter++)
                    {
                        if (!Directory.Exists(listFolder[iter]))
                            Directory.CreateDirectory(listFolder[iter]);
                    }
                }
            }

            catch (Exception e)
            {
                MessageBox.Show("Maaf, Alamat folder tidak benar, Error : " + e.ToString());
            }
            
            return listFolder;
        }

        public String[] listFile(String folder)
        {
            return Directory.GetFiles(folder);
        }
    }
}
