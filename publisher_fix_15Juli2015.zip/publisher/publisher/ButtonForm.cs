﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace publisher
{
    class ButtonForm
    {
        int iter;
        public int enableOrDisable(String ctrName, String btnName, int disableLength)
        {
            for (iter = 2; iter <= disableLength; iter++)
            {
                if (ctrName == (btnName + iter.ToString())) return 0;
            }
            return 1;  
        }
    }
}
