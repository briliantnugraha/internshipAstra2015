﻿namespace publisher
{
    partial class setConnstringAndDatabase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.browseConnstring = new System.Windows.Forms.Button();
            this.setConnstrAndDB = new System.Windows.Forms.Button();
            this.listDB = new System.Windows.Forms.ComboBox();
            this.List_Database = new System.Windows.Forms.Label();
            this.Database_Name = new System.Windows.Forms.Label();
            this.addDatabase = new System.Windows.Forms.Button();
            this.User_ID = new System.Windows.Forms.Label();
            this.dbName = new System.Windows.Forms.TextBox();
            this.Connstring = new System.Windows.Forms.TextBox();
            this.Default = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // browseConnstring
            // 
            this.browseConnstring.Location = new System.Drawing.Point(256, 37);
            this.browseConnstring.Name = "browseConnstring";
            this.browseConnstring.Size = new System.Drawing.Size(71, 25);
            this.browseConnstring.TabIndex = 24;
            this.browseConnstring.Text = "Browse";
            this.browseConnstring.UseVisualStyleBackColor = true;
            this.browseConnstring.Click += new System.EventHandler(this.browseConnstring_Click);
            // 
            // setConnstrAndDB
            // 
            this.setConnstrAndDB.Location = new System.Drawing.Point(123, 204);
            this.setConnstrAndDB.Name = "setConnstrAndDB";
            this.setConnstrAndDB.Size = new System.Drawing.Size(112, 36);
            this.setConnstrAndDB.TabIndex = 23;
            this.setConnstrAndDB.Text = "Set Connstring and Database";
            this.setConnstrAndDB.UseVisualStyleBackColor = true;
            this.setConnstrAndDB.Click += new System.EventHandler(this.setConnstrAndDB_Click);
            // 
            // listDB
            // 
            this.listDB.FormattingEnabled = true;
            this.listDB.Location = new System.Drawing.Point(125, 161);
            this.listDB.Name = "listDB";
            this.listDB.Size = new System.Drawing.Size(202, 21);
            this.listDB.TabIndex = 22;
            // 
            // List_Database
            // 
            this.List_Database.AutoSize = true;
            this.List_Database.Location = new System.Drawing.Point(33, 164);
            this.List_Database.Name = "List_Database";
            this.List_Database.Size = new System.Drawing.Size(72, 13);
            this.List_Database.TabIndex = 21;
            this.List_Database.Text = "List Database";
            // 
            // Database_Name
            // 
            this.Database_Name.AutoSize = true;
            this.Database_Name.Location = new System.Drawing.Point(33, 84);
            this.Database_Name.Name = "Database_Name";
            this.Database_Name.Size = new System.Drawing.Size(84, 13);
            this.Database_Name.TabIndex = 20;
            this.Database_Name.Text = "Database Name";
            // 
            // addDatabase
            // 
            this.addDatabase.Location = new System.Drawing.Point(256, 112);
            this.addDatabase.Name = "addDatabase";
            this.addDatabase.Size = new System.Drawing.Size(71, 43);
            this.addDatabase.TabIndex = 19;
            this.addDatabase.Text = "Add Database";
            this.addDatabase.UseVisualStyleBackColor = true;
            this.addDatabase.Click += new System.EventHandler(this.addDatabase_Click);
            // 
            // User_ID
            // 
            this.User_ID.AutoSize = true;
            this.User_ID.Location = new System.Drawing.Point(33, 40);
            this.User_ID.Name = "User_ID";
            this.User_ID.Size = new System.Drawing.Size(69, 13);
            this.User_ID.TabIndex = 18;
            this.User_ID.Text = "Server Name";
            // 
            // dbName
            // 
            this.dbName.Location = new System.Drawing.Point(123, 81);
            this.dbName.Multiline = true;
            this.dbName.Name = "dbName";
            this.dbName.Size = new System.Drawing.Size(204, 25);
            this.dbName.TabIndex = 17;
            // 
            // Connstring
            // 
            this.Connstring.Location = new System.Drawing.Point(125, 37);
            this.Connstring.Multiline = true;
            this.Connstring.Name = "Connstring";
            this.Connstring.Size = new System.Drawing.Size(110, 25);
            this.Connstring.TabIndex = 16;
            // 
            // Default
            // 
            this.Default.Location = new System.Drawing.Point(249, 204);
            this.Default.Name = "Default";
            this.Default.Size = new System.Drawing.Size(78, 36);
            this.Default.TabIndex = 25;
            this.Default.Text = "Default";
            this.Default.UseVisualStyleBackColor = true;
            this.Default.Click += new System.EventHandler(this.Default_Click);
            // 
            // setConnstringAndDatabase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(373, 261);
            this.Controls.Add(this.Default);
            this.Controls.Add(this.browseConnstring);
            this.Controls.Add(this.setConnstrAndDB);
            this.Controls.Add(this.listDB);
            this.Controls.Add(this.List_Database);
            this.Controls.Add(this.Database_Name);
            this.Controls.Add(this.addDatabase);
            this.Controls.Add(this.User_ID);
            this.Controls.Add(this.dbName);
            this.Controls.Add(this.Connstring);
            this.Name = "setConnstringAndDatabase";
            this.Text = "Set Connstring And Database";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button browseConnstring;
        private System.Windows.Forms.Button setConnstrAndDB;
        private System.Windows.Forms.ComboBox listDB;
        private System.Windows.Forms.Label List_Database;
        private System.Windows.Forms.Label Database_Name;
        private System.Windows.Forms.Button addDatabase;
        private System.Windows.Forms.Label User_ID;
        private System.Windows.Forms.TextBox dbName;
        private System.Windows.Forms.TextBox Connstring;
        private System.Windows.Forms.Button Default;
    }
}