﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace publisher
{
    class ConnStringAndDatabase
    {
        private XmlWriter writerXML;
        private XmlDocument xdoc;
        private XmlNode node;
        private XmlElement element;
        private XmlNodeList list;
        private String Messenger;
        private int iter;

        public void checkServer(String directory, String server)
        {
            try
            {
                if (!Directory.Exists(directory + "/config/")) Directory.CreateDirectory(directory + "/config/");
                if (!File.Exists(directory + "/config/server.xml") 
                    && !String.IsNullOrEmpty(server)
                    && !String.IsNullOrWhiteSpace(server))
                {
                    writerXML = XmlWriter.Create(directory + "/config/server.xml");
                    writerXML.WriteStartDocument(true);
                    writerXML.WriteStartElement("server");
                    writerXML.WriteElementString("server_used", server);
                    writerXML.WriteEndElement();
                    writerXML.WriteEndDocument();
                    writerXML.Close();
                }

                else if( !String.IsNullOrEmpty(server)
                    && !String.IsNullOrWhiteSpace(server))
                {
                    xdoc = new XmlDocument();
                    xdoc.Load(directory + "/config/server.xml");
                    node = xdoc.SelectSingleNode("server/server_used");
                    node.InnerText = server;
                    xdoc.Save(directory + "/config/server.xml");
                }
            }

            catch(Exception e)
            {
                System.Windows.Forms.MessageBox.Show("Terjadi kesalahan ketika mengatur server, Error : " + e.ToString());
            }
        }

        public void checkDB(String directory, String textbox)
        {
            if (!String.IsNullOrWhiteSpace(textbox) && !String.IsNullOrEmpty(textbox))
            {
                if (!Directory.Exists(directory + "/config/")) Directory.CreateDirectory(directory + "/config/");
                if (!File.Exists(directory + "/config/list_db.xml"))
                {
                    writerXML = XmlWriter.Create(directory + "/config/" + "list_db.xml");
                    writerXML.WriteStartDocument(true);
                    writerXML.WriteStartElement("list_db");
                    writerXML.WriteElementString("db_used", textbox);
                    writerXML.WriteElementString(textbox, textbox);
                    writerXML.WriteEndElement();
                    writerXML.WriteEndDocument();
                    writerXML.Close();
                }

                else
                {
                    xdoc = new XmlDocument();
                    xdoc.Load(directory + "/config/" + "list_db.xml");
                    node = xdoc.SelectSingleNode("list_db/db_used");
                    node.InnerText = textbox;

                    node = null;
                    node = xdoc.SelectSingleNode("list_db/" + textbox);
                    if (node == null)
                    {
                        System.Windows.Forms.MessageBox.Show("List belum ada, " + textbox + " ditambahkan ke daftar");
                        element = xdoc.CreateElement(textbox);
                        element.InnerText = textbox;
                        xdoc.DocumentElement.AppendChild(element);
                        xdoc.Save(directory + "/config/" + "list_db.xml");
                    }

                    else System.Windows.Forms.MessageBox.Show("Maaf, database yang diisikan sudah ada!");
                }
            }
            else System.Windows.Forms.MessageBox.Show("Maaf, database yang diisikan kosong / tidak valid!");
        }

        public String loadListDB(String directory)
        {
            Messenger = null;
            if (File.Exists(directory + "/config/list_db.xml"))
            {
                xdoc = new XmlDocument();
                xdoc.Load(directory + "/config/list_db.xml");
                element = xdoc.DocumentElement;
                list = null;
                list = element.ChildNodes;
                for (iter = 0; iter < list.Count; iter++) Messenger += list[iter].InnerText + "\n";
            }
            return Messenger;
        }

        public void setConnstrAndDB(String directory, String server, String dbName, String dirJob, String listOfJob)
        {
            this.checkServer(directory, server);
            xdoc = new XmlDocument();
            String[] listOfJobSplit = listOfJob.Split('\n');
            
            for (iter = 0; iter < listOfJobSplit.Length - 1; iter++)
            {
                listOfJobSplit[iter] = listOfJobSplit[iter].Remove(listOfJobSplit[iter].Length - 1);
                try
                {
                    xdoc.Load(dirJob + listOfJobSplit[iter] + ".xml");
                    if (System.IO.Path.GetFileName(listOfJobSplit[iter]).Split('_')[0] == "PSS")
                    {
                        node = null;
                        node = xdoc.SelectSingleNode("jobs/connstring");
                        node.InnerText = server;
                    }
                    node = xdoc.SelectSingleNode("jobs/database_name");
                    node.InnerText = dbName;
                    xdoc.Save(dirJob + listOfJobSplit[iter] + ".xml");
                }
                
                catch(Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(dirJob +
                        listOfJobSplit[iter] + ".xml tidak ada, Error : " + e.ToString());
                }
            }
            System.Windows.Forms.MessageBox.Show("Connstring dan database akan diedit ke script berikut:\n" + listOfJob);
        }

        public String getConnString(String directory)
        {
            this.checkServer(directory, null);
            try
            {
                xdoc = new XmlDocument();
                xdoc.Load(directory + "/config/server.xml");
                node = xdoc.SelectSingleNode("server/server_used");
                return node.InnerText.ToString();
            }
            catch(Exception e)
            {
                System.Windows.Forms.MessageBox.Show("Error ketika mendapatkan server, error : " + e.ToString());
                return null;
            }
        }

        public String getSelectedDB(String directory)
        {
            if (!Directory.Exists(directory + "/config/")) Directory.CreateDirectory(directory + "/config/");
            try
            {
                xdoc = new XmlDocument();
                xdoc.Load(directory + "/config/list_db.xml");
                node = xdoc.SelectSingleNode("list_db/db_used");
                return node.InnerText.ToString();
            }

            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show("Error ketika mendapatkan list database, error : " + e.ToString());
                return null;
            }
        }
    }
}
