﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace publisher
{
    class load
    {
        private int iter;
        private String getExecETLName,getNodeName, simpanQuery;
        private XmlDocument xdoc;
        private XmlNodeList listNode;
        private TextWriter writer;

        public void LoadAll(String dirJobs, String dirExecETL, String dirSP)
        {
            String[] listJob = System.IO.Directory.GetFiles(dirJobs);
            String[] listExecETL = System.IO.Directory.GetFiles(dirExecETL);
            String[] listSP = System.IO.Directory.GetFiles(dirSP);
            loadJob(listJob);
            loadExecETL(listExecETL);
            loadSP(listSP);
            System.Windows.Forms.MessageBox.Show("Load berhasil dilakukan");
        }

        private void loadJob(String[] listJob)
        {
            for (iter = 0; iter < listJob.Length; iter++)
            {
                if (System.IO.Path.GetExtension(listJob[iter]) == ".xml")
                {
                    try
                    {
                        String[] list2 = listJob[iter].Split('/');
                        xdoc = new XmlDocument();
                        xdoc.Load(listJob[iter]);
                        getExecETLName = String.Empty;
                        getExecETLName = xdoc.SelectSingleNode("jobs/store_procedure").InnerText;

                        listNode = null;
                        listNode = xdoc.SelectNodes("jobs");
                        getNodeName = String.Empty;
                        foreach (XmlNode node2 in listNode[0])
                        {
                            getNodeName = '[' + node2.Name + ']';
                            //if (getExecETL.Contains(getnodeName)) MessageBox.Show(getnodeName);
                            getExecETLName = getExecETLName.Replace(getNodeName, node2.InnerText);
                        }
                        writer = new StreamWriter(listJob[iter].Remove(listJob[iter].Length - 4) + ".sql");
                        writer.WriteLine(getExecETLName);
                        writer.Close();
                        File.Delete(listJob[iter]);
                    }
                    catch (Exception e)
                    {
                        System.Windows.Forms.MessageBox.Show("Error ketika load Job, error : " + e.ToString());
                    }
                }
            }
        }

        private void loadExecETL(String[] listExecETL)
        {
            for (iter = 0; iter < listExecETL.Length; iter++)
            {
                if (System.IO.Path.GetExtension(listExecETL[iter]) == ".xml")
                {
                    try
                    {
                        String[] listToExecETL = listExecETL[iter].Split('/');

                        simpanQuery = null;
                        getExecETLName = null;
                        xdoc = new XmlDocument();

                        xdoc.Load(listExecETL[iter]);
                        listNode = null;
                        listNode = xdoc.SelectNodes("executeETL");
                        getExecETLName = listNode[0].ChildNodes[3].InnerText;
                        foreach (XmlNode node in listNode[0])
                        {
                            if (node.Name == "SOTransDB")
                            {
                                if (node.InnerText == String.Empty || node.InnerText.Trim().Length == 0)
                                    getExecETLName = getExecETLName.Replace(node.Name, "null");
                                else getExecETLName = getExecETLName.Replace(node.Name, "'" + node.InnerText + "'");
                            }
                            if (node.Name == "ETLProcessName") getExecETLName = getExecETLName.Replace(node.Name, "'" + node.InnerText + "'");

                            if (node.Name == "RetrieveQuery")
                            {
                                if (node.InnerText == String.Empty || node.InnerText.Trim().Length == 0) simpanQuery = "null";
                                else simpanQuery = node.InnerText;
                                continue;
                            }
                            else getExecETLName = getExecETLName.Replace(node.Name, "null");
                        }
                        simpanQuery = simpanQuery.Replace("'", "''");
                        if (simpanQuery != "null") getExecETLName = getExecETLName.Replace("RetrieveQuery", "'" + simpanQuery + "'");
                        else getExecETLName = getExecETLName.Replace("RetrieveQuery", simpanQuery);
                        getExecETLName = getExecETLName.Remove(29, 1).Insert(29, "(CreatedBy, CreatedTime, ETLProcessName,RetrieveQuery,SOTransDB) ");
                        writer = new StreamWriter(listExecETL[iter].Remove(listExecETL[iter].Length - 4) + ".sql");
                        writer.WriteLine(getExecETLName);
                        writer.Close();
                        File.Delete(listExecETL[iter]);
                    }
                    catch (Exception e)
                    {
                        System.Windows.Forms.MessageBox.Show("Error ketika load ExecETL, error : " + e.ToString());
                    }
                }
            }
        }

        private void loadSP(String[] listSP)
        {
            for(iter=0; iter < listSP.Length; iter++)
            {
                try
                {
                    File.Copy(listSP[iter], listSP[iter].Remove(listSP[iter].Length - 4) + ".sql");
                    File.Delete(listSP[iter]);
                }
                catch(Exception e)
                {
                    System.Windows.Forms.MessageBox.Show("Error ketika load SP, error : " + e.ToString());
                }
            }
        }
    }
}
